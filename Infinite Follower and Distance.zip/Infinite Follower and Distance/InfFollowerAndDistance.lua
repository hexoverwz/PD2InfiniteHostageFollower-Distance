-- Infinite hostage followers
-- Author: rogerxiii / DvD
tweak_data.player.max_nr_following_hostages = 1000
-- Infinite hostage follower distance
	-- Author: rogerxiii / DvD
local old_set_objective = CopBrain.set_objective
	function CopBrain:set_objective(new_objective, params)
		if new_objective and new_objective.lose_track_dis then new_objective.lose_track_dis = 5000000 end
		old_set_objective(self, new_objective, params)
	end